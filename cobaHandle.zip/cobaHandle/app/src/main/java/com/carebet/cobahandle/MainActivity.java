 package com.carebet.cobahandle;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

 public class MainActivity extends AppCompatActivity {
TextView textView;
int hit=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.text);
        content();
    }
    public void content(){
        hit++;
        textView.setText("test "+hit);
        reload(1);
    }
    private void reload(long delay){
        final Handler handler=new Handler();
        final Runnable runnable=new Runnable() {
            @Override
            public void run() {
          content();
            }
        };
        handler.postDelayed(runnable,delay);
    }
}
