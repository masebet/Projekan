bool mode_1_go = false;
bool mode_2_ke_A = false;
bool mode_2_ke_B = false;
bool mode_2_ke_C = false;




bool mode_2_go = false;
String Huruf;

String RFID_1, RFID_2;
String AKSI_1, AKSI_2;

String abc[] = "";


String RFID[jumlahRFID];
String AKSI[jumlahRFID];
