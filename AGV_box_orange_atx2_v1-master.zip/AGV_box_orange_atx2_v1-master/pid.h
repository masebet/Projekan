int gasKiri;
int gasKanan;
double error;
int steer;
int lastError;

unsigned long lastTime;
double Input, Output, Setpoint;
double errSum, lastErr;
double kp,kd,ki;

int berhenti = 127;

//-----------------------------------------------------------PID tunings------------------------------------------
void SetTunings(double Kp, double Ki, double Kd){
   kp = Kp;
   ki = Ki;
   kd = Kd * 100;

//   kp = Kp;
//   ki = Ki;
//   kd = Kd;
}
//-----------------------------------------------------------PID error--------------------------------------------
void Compute(){
//   SetTunings(3, ki, 0);
   SetTunings(gainP, 0, gainD);
   
   unsigned long now = millis();
   double timeChange = (double)(now - lastTime);
   error = (int32_t)pixy.frameWidth/2 - pixy.line.vectors->m_x1;
   errSum += (error * timeChange);
   double dErr = (error - lastErr) / timeChange;
   Output = kp * error + ki * errSum + kd * dErr;
   lastErr = error;
   lastTime = now;
}
