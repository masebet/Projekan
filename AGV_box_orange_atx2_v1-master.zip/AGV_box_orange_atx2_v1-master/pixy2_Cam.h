Pixy2I2C pixy;

void setup_pixyCam(){
  pixy.init();
  pixy.setLamp(1, 1);
  Serial.println(pixy.changeProg("line"));
//  Serial.println("cek");
}
