// =========================== inisialisasi Pin-pin Tombol ===========================
#define pinPlus 31
#define pinMinus 30
#define pinOk 29
#define pinNaik 28
#define pinTurun 27
#define pinStopResume 26
#define pinEmergency 25
#define pinLedEmergency 24

#define tombolPlus       digitalRead(pinPlus)  == 0
#define tombolMinus      digitalRead(pinMinus) == 0
#define tombolOk         digitalRead(pinOk) == 0
#define tombolNaik       digitalRead(pinNaik)  == 0
#define tombolTurun      digitalRead(pinTurun) == 0
#define tombolStopResume digitalRead(pinStopResume) == 0
#define tombolEmergency  digitalRead(pinEmergency) == 0

#define ledEmergencyOn     digitalWrite(pinLedEmergency, HIGH)
#define ledEmergencyOff    digitalWrite(pinLedEmergency, LOW)

#define pinSensorJarakA 13
#define pinSensorJarakB 14
#define pinSensorJarakC 15

#define sensorJarakA   digitalRead(pinSensorJarakA) == 0
#define sensorJarakB   digitalRead(pinSensorJarakB) == 0
#define sensorJarakC   digitalRead(pinSensorJarakC) == 0
// =========================== inisialisasi Pin-pin Tombol ===========================

// =========================== inisialisasi Pin-pin Motor ===========================
#define arahMotorKanan 5
#define motorKanan 6

#define arahMotorKiri 4
#define motorKiri 7
// =========================== inisialisasi Pin-pin Motor ===========================

int menu_utama = 0;
int mode_1 = 1;
int mode_2 = 2;
int setting = 3;

int menu = menu_utama;

int pilihmenu = 0;
int menu_setting = 0;

int set_speed;
String setting_speed;
int address_speed = 0;


int gainP;    // default value of P = 1
String P;
int address_gainP = 1;

int gainD;   // default value of D = 1000
String D;
int address_gainD = 2;


void setup_pin(){
  pinMode(arahMotorKanan, OUTPUT);
  pinMode(arahMotorKiri, OUTPUT);
  
  pinMode(pinSensorJarakA,INPUT);
  pinMode(pinSensorJarakB,INPUT);
  pinMode(pinSensorJarakC,INPUT);

  pinMode(pinLedEmergency,OUTPUT);
}

