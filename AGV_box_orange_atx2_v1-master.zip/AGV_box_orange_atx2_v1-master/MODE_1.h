void PILIH_MODE_1(String RFID, String AKSI) {
   if(baca_tag() == RFID){

// ==========================================================================     
     while(AKSI == "berhenti"){
       tampilan_telah_sampai();
       robotBerhenti();
       baca_tag();
       fungsi_emergency();
       if(tombolOk) {
         tampilan_mode_1_go();
         AKSI = "";
         fungsi_emergency();
         break;
       }
       if(tombolStopResume){
         tampilan_pilih_menu_utama();
         mode_1_go = false;
         AKSI = "";
         fungsi_emergency();
         break;
       }
     }
// ==========================================================================     

// ==========================================================================     
     while(AKSI == "belok_kiri"){
       tampilan_belok_kiri();
       robotBerhenti();
       delay(1000);
       baca_tag();
       fungsi_emergency();
       belokKiriTerus_0:
         bantingKiri(1.5);
         baca_tag();
         fungsi_emergency();
         pixy.line.getMainFeatures();
         if(!pixy.line.numVectors) {
           belokKiriTerus_1:
             bantingKiri(0.5);
             baca_tag();
             Compute();
             fungsi_emergency();
             pixy.line.getMainFeatures();
             if(pixy.line.numVectors) {
                 tampilan_mode_1_go();
                 fungsi_emergency();
                 break;
             }
           goto belokKiriTerus_1;
         }
        goto belokKiriTerus_0;

       if(tombolOk) {
         tampilan_mode_1_go();
         AKSI = "";
         fungsi_emergency();
         break;
       }
       if(tombolStopResume){
         tampilan_pilih_menu_utama();
         mode_1_go = false;
         AKSI = "";
         fungsi_emergency();
         break;
       }
     }
// ==========================================================================

// ==========================================================================     
     while(AKSI == "belok_kanan"){
       tampilan_belok_kanan();
       robotBerhenti();
       delay(1000);
       baca_tag();
       fungsi_emergency();
       belokKananTerus_0:
         bantingKanan(1.5);
         baca_tag();
         fungsi_emergency();
         pixy.line.getMainFeatures();
         if(!pixy.line.numVectors) {
           belokKananTerus_1:
             bantingKanan(0.5);
             baca_tag();
             Compute();
             fungsi_emergency();
             pixy.line.getMainFeatures();
             if(pixy.line.numVectors) {
                 tampilan_mode_1_go();
                 fungsi_emergency();
                 break;
             }
           goto belokKananTerus_1;
         }
        goto belokKananTerus_0;

       if(tombolOk) {
         tampilan_mode_1_go();
         AKSI = "";
         fungsi_emergency();
         break;
       }
       if(tombolStopResume){
         tampilan_pilih_menu_utama();
         mode_1_go = false;
         AKSI = "";
         fungsi_emergency();
         break;
       }
     }
// ==========================================================================

   }
}

// -------------------------- EDIT disini untuk menambahkan RFID dan AKSI nya --------------------------
/* AKSI nya ada 3 buah
  // "berhenti"
  // "belok_kiri"
  // "belok_kanan"
*/

// PILIH_MODE_1("RFID", "AKSI");
// CONTOH
/*
  PILIH_MODE_1("c468f15f", "berhenti");
*/

void MODE_1(){
  PILIH_MODE_1("c468f15f", "berhenti");
  PILIH_MODE_1("a9195e34", "berhenti");
  PILIH_MODE_1("2918cf34", "berhenti");
}
// -------------------------- EDIT disini untuk menambahkan RFID dan AKSI nya --------------------------
