void MODE_2_GO() {
  for(int i = 0; i < jumlahRFID; i++) {  
  // --------------------------------------------- RFID_1 ---------------------------------------------
    if(baca_tag() == RFID[i]){
  // ==========================================================================     
       if(AKSI[i] == "berhenti"){
         while(AKSI[i] == "berhenti"){
           tampilan_telah_sampai();
           robotBerhenti();
           baca_tag();
           fungsi_emergency();
           if(tombolOk) {
             tampilan_mode_2_go_ke(Huruf);
             AKSI[i] = "";
             fungsi_emergency();
             break;
           }
           if(tombolStopResume){
             tampilan_pilih_menu_utama();
             mode_2_go = false;
             AKSI[i] = "";
             fungsi_emergency();
             break;
           }
         }
       }
  // ==========================================================================     
  
  // ==========================================================================     
       if(AKSI[i] == "belok_kiri"){
         tampilan_belok_kiri();
         robotBerhenti();
         delay(1000);
         baca_tag();
         fungsi_emergency();
         while(AKSI[i] == "belok_kiri"){
           bantingKiri(1.5);
           baca_tag();
           fungsi_emergency();
           pixy.line.getMainFeatures();
           if(!pixy.line.numVectors) {
             while(AKSI[i] == "belok_kiri"){
               bantingKiri(0.5);
               baca_tag();
               Compute();
               fungsi_emergency();
               pixy.line.getMainFeatures();
               if(pixy.line.numVectors) {
                   tampilan_mode_2_go_ke(Huruf);
                   AKSI[i] == "";
                   fungsi_emergency();
                   goto keluar_dari_bantingan;
               }
             }
           }
         }
       }
  // ==========================================================================
  
  // ==========================================================================     
       if(AKSI[i] == "belok_kanan"){
         tampilan_belok_kanan();
         robotBerhenti();
         delay(1000);
         baca_tag();
         fungsi_emergency();
         while(AKSI[i] == "belok_kanan"){
           bantingKanan(1.5);
           baca_tag();
           fungsi_emergency();
           pixy.line.getMainFeatures();
           if(!pixy.line.numVectors) {
             while(AKSI[i] == "belok_kanan"){
               bantingKanan(0.5);
               baca_tag();
               Compute();
               fungsi_emergency();
               pixy.line.getMainFeatures();
               if(pixy.line.numVectors) {
                 tampilan_mode_2_go_ke(Huruf);
                 AKSI[i] == "";
                 fungsi_emergency();
                 goto keluar_dari_bantingan;
               }
             }
           }
         }
       }
  // ==========================================================================
    }
  // --------------------------------------------- RFID_1 ---------------------------------------------
  
  
  
    keluar_dari_bantingan:;
  }

}
