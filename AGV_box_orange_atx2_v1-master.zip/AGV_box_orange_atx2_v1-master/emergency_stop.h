void fungsi_emergency(){
  if(tombolEmergency) {
    emergencyy:
      robotBerhenti();
      ledEmergencyOn;
      tampilan_emergency();
      if(!tombolEmergency){
        tampilan_kosong();
        goto keluaremergencyy;
      }
    goto emergencyy;
  }
  keluaremergencyy:
  ledEmergencyOff;
}
