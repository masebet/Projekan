int default_speed = 127;
int batas_maksimal_speed;
int batas_minimal_speed;


void belokKiri() {
  batas_maksimal_speed = default_speed + set_speed;
  batas_minimal_speed = default_speed - set_speed * 0.8;
  gasKiri = batas_minimal_speed;
  gasKanan = batas_maksimal_speed;
  digitalWrite(arahMotorKanan, LOW);
  digitalWrite(arahMotorKiri, LOW);
  analogWrite(motorKiri, gasKiri);
  analogWrite(motorKanan, gasKanan);
}

void belokKanan() {
  batas_maksimal_speed = default_speed + set_speed;
  batas_minimal_speed = default_speed - set_speed * 0.8;
  gasKiri = batas_maksimal_speed;
  gasKanan = batas_minimal_speed;

  digitalWrite(arahMotorKanan, LOW);
  digitalWrite(arahMotorKiri, LOW);
  analogWrite(motorKiri, gasKiri);
  analogWrite(motorKanan, gasKanan);
}

void bantingKanan(float level) {
  batas_maksimal_speed = default_speed + set_speed * level;
  batas_minimal_speed = default_speed - set_speed;
  gasKiri = batas_maksimal_speed;
  gasKanan = batas_minimal_speed;

  digitalWrite(arahMotorKanan, LOW);
  digitalWrite(arahMotorKiri, LOW);
  analogWrite(motorKiri, gasKiri);
  analogWrite(motorKanan, gasKanan);
}

void bantingKiri(float level) {
  batas_maksimal_speed = default_speed + set_speed * level;
  batas_minimal_speed = default_speed - set_speed;
  gasKiri = batas_minimal_speed;
  gasKanan = batas_maksimal_speed;
  digitalWrite(arahMotorKanan, LOW);
  digitalWrite(arahMotorKiri, LOW);
  analogWrite(motorKiri, gasKiri);
  analogWrite(motorKanan, gasKanan);
}

void robotBerhenti() {
  gasKiri = 127;
  gasKanan = 127;
  digitalWrite(arahMotorKanan, LOW);
  digitalWrite(arahMotorKiri, LOW);
  analogWrite(motorKiri, gasKiri);
  analogWrite(motorKanan, gasKanan);
}

void Mengikuti_Garis() {
    Compute();
    batas_maksimal_speed = default_speed + set_speed;
    batas_minimal_speed = default_speed - set_speed;
    
    gasKiri = berhenti + (int)set_speed + (int) Output;
      if (gasKiri <= batas_minimal_speed)    gasKiri = batas_minimal_speed;
      if (gasKiri >= batas_maksimal_speed)   gasKiri = batas_maksimal_speed;  // batas maksimal kecepatan
    gasKanan = berhenti + (int)set_speed - (int) Output;
      if (gasKanan <= batas_minimal_speed)   gasKanan = batas_minimal_speed;
      if (gasKanan >= batas_maksimal_speed)  gasKanan = batas_maksimal_speed;
    
    if(sensorJarakA || sensorJarakB || sensorJarakC) {
      robotBerhenti();
    }
    else{
      digitalWrite(arahMotorKanan, LOW);
      digitalWrite(arahMotorKiri, LOW);
      analogWrite(motorKiri, gasKiri);
      analogWrite(motorKanan, gasKanan);
    }
}





