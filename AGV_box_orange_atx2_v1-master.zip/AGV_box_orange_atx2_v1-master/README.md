# AGV_box_orange_atx2_v1
agv box orange dengan kontroler ATX2
