void setup_tombol(){
  pinMode(pinPlus,INPUT_PULLUP);
  pinMode(pinMinus,INPUT_PULLUP);
  pinMode(pinNaik,INPUT_PULLUP);
  pinMode(pinTurun,INPUT_PULLUP);
  pinMode(pinOk,INPUT_PULLUP);
  pinMode(pinStopResume,INPUT_PULLUP);
  pinMode(pinEmergency,INPUT_PULLUP);
}

void pencet_tombol(){
  if(tombolNaik) {
    delay(250);
    pilihmenu = pilihmenu - 1;
  }
  else if(tombolTurun) {
    delay(250);
    pilihmenu = pilihmenu + 1;
  }
}
