// ======================================= menu utama =======================================
void tampilan_pilih_menu_utama() {
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("  *Menu*");
  display.println(" Mode 1");
  display.println(" Mode 2");
  display.println(" Setting");
  display.display();
}
// ======================================= menu utama =======================================

// =======================================   mode 1   =======================================
void tampilan_pilih_mode_1() {
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("  *Menu*");
  display.println(">Mode 1");
  display.println(" Mode 2");
  display.println(" Setting");
  display.display();
}

void tampilan_mode_1(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" *Mode 1*");
  display.println(">Back");
  display.println(" Go");
  display.display();
}

void tampilan_mode_1_pilih_back(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" *Mode 1*");
  display.println(">Back");
  display.println(" Go");
  display.display();
}

void tampilan_mode_1_pilih_go(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" *Mode 1*");
  display.println(" Back");
  display.println(">Go");
  display.display();
}

void tampilan_mode_1_go(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" *Mode 1*");
  display.println("");
  display.println(" GooOOOO");
  display.display();
}
// =======================================   mode 1   =======================================

// =======================================   mode 2   =======================================
void tampilan_pilih_mode_2() {
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("  *Menu*");
  display.println(" Mode 1");
  display.println(">Mode 2");
  display.println(" Setting");
  display.display();
}

void tampilan_mode_2(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" *Mode 2*");
  display.println(">Back");
  display.println(" to A");
  display.display();
}

void tampilan_mode_2_pilih_back(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" *Mode 2*");
  display.println(">Back");
  display.println(" to A");
  display.display();
}

void tampilan_mode_2_pilih_ke(String TUJUAN){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" *Mode 2*");
  display.println("          ");
  display.println(">to " + TUJUAN);
  display.display();
}

void tampilan_mode_2_go_ke(String TUJUAN){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" *Mode 2*");
  display.println("  Go To  ");
  display.println("    " + TUJUAN);
  display.display();
}
// =======================================   mode 2   =======================================


// =======================================   setting  =======================================
void tampilan_pilih_setting(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("  *Menu*");
  display.println(" Mode 1");
  display.println(" Mode 2");
  display.println(">Setting");
  display.display();
}

void tampilan_setting(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(">Back");
  display.println(" Speed:" + setting_speed);
  display.println(" P:" + P);
  display.println(" D:" + D);
  display.display();
}

void tampilan_setting_pilih_back(){
  setting_speed = String(set_speed);
  P = String(gainP);
  D = String(gainD);
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(">Back");
  display.println(" Speed:" + setting_speed);
  display.println(" P:" + P);
  display.println(" D:" + D);
  display.display();
}

void tampilan_setting_pilih_speed(){
  if(tombolPlus) {delay(100); set_speed++;}
  if(tombolMinus){delay(100); set_speed--;}
  if(set_speed < 0)   set_speed = 0;
  if(set_speed > 100) set_speed = 100;
  EEPROM.write(address_speed, set_speed); // simpan data set_speed
  
  setting_speed = String(set_speed);
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" Back");
  display.println(">Speed:" + setting_speed);
  display.println(" P:" + P);
  display.println(" D:" + D);
  display.display();
}

void tampilan_setting_pilih_gain_P(){
  if(tombolPlus) {delay(100); gainP++;}
  if(tombolMinus){delay(100); gainP--;}
  if(gainP < 0)   gainP  = 0;
  if(gainP > 10)  gainP  = 10;
  EEPROM.write(address_gainP, gainP); // simpan data P
  SetTunings(gainP, 0, gainD);
  
  P = String(gainP);
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" Back");
  display.println(" Speed:" + setting_speed);
  display.println(">P:" + P);
  display.println(" D:" + D);
  display.display();
}

void tampilan_setting_pilih_gain_D(){
  if(tombolPlus) {delay(100); gainD++;}
  if(tombolMinus){delay(100); gainD--;}
  if(gainD < 0)       gainD  = 0;
  if(gainD > 100)     gainD  = 100;
  EEPROM.write(address_gainD, gainD); // simpan data D
  SetTunings(gainP, 0, gainD);
  
  D = String(gainD);
  display.clearDisplay();
  display.setCursor(0,0);
  display.println(" Back");
  display.println(" Speed:" + setting_speed);
  display.println(" P:" + P);
  display.println(">D:" + D);
  display.display();
}

void tampilan_baca_rfid(){
  if(baca_tag() == "ffffffff") {
    display.clearDisplay();
    display.setCursor(0,0);
    display.println(" RFID ");
    display.println();
    display.println("            ");
    display.display();
  }
  else {
    display.clearDisplay();
    display.setCursor(0,0);
    display.println(" RFID ");
    display.println();
    display.println(baca_tag());
    display.display();
  }
}
// =======================================   setting  =======================================

// ===================================   Sampai Tujuan   ====================================
void tampilan_telah_sampai(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("         ");
  display.println(" Arrived ");
  display.println("         ");
  display.display();
}
// ===================================   Sampai Tujuan   ====================================

// ===================================   Belok Kiri   ====================================
void tampilan_belok_kiri(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("          ");
  display.println("   Turn   ");
  display.println("   LEFT   ");
  display.display();
}
// ===================================   Belok Kiri   ====================================

// ===================================   Belok Kanan   ====================================
void tampilan_belok_kanan(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("          ");
  display.println("   Turn   ");
  display.println("   RIGHT  ");
  display.display();
}
// ===================================   Belok Kanan   ====================================

void tampilan_emergency(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("          ");
  display.println(" Emergency");
  display.println("   Stop   ");
  display.display();
}

void tampilan_kosong(){
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("          ");
  display.println("          ");
  display.println("          ");
  display.display();
}
