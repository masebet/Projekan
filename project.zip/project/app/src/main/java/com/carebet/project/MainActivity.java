package com.carebet.project;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    String suhu="harap tunggu";
    String detak="harap tunggu";
    String otot="harap tunggu";
    private String TAG = MainActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private TextView lv;
    private TextView lv2;
    private TextView lv3;
    private static String url = "http://192.168.4.1/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (TextView) findViewById(R.id.detak);
        lv2 = (TextView) findViewById(R.id.suhu);
        lv3 = (TextView) findViewById(R.id.otot);
        content();
    }
    public void content(){
        new GetContacts().execute();
        reload(10);
    }
    private void reload(long delay){
        final Handler handler=new Handler();
        final Runnable runnable=new Runnable() {
            @Override
            public void run() {
                content();
            }
        };
        handler.postDelayed(runnable,delay);
    }

    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Sedang Mencari Koneksi");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);
            Log.e(TAG, "Response from url: " + jsonStr);
            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
//                    lv.setText(jsonObj.getString("suhu"));
//                    lv2.setText(jsonObj.getString("detak"));
                    detak = jsonObj.getString("detak");
                    suhu = jsonObj.getString("suhu");
                    otot = jsonObj.getString("otot");
                } catch (final JSONException e) {
                    Log.e(TAG, "eror" + e.getMessage());
                    runOnUiThread(new Runnable() {@Override public void run() { Toast.makeText(getApplicationContext(), "eror kenapa?" + e.getMessage(), Toast.LENGTH_LONG).show(); }}); }
            } else {
                runOnUiThread(new Runnable() {@Override public void run() { Toast.makeText(getApplicationContext(), "gak bisa " , Toast.LENGTH_LONG).show(); }});
                detak="error";
                suhu="error";
                otot="error";
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            if (pDialog.isShowing()) pDialog.dismiss();   // Dismiss the progress dialog
            /**
             * Updating parsed JSON data into ListView
             * */
            lv3.setText("Nilai Sensor Otot : "+otot);
            lv2.setText("Nilai Sensor Detak : "+detak);
            lv.setText("Nilai Sensor Suhu : "+suhu);
        }
    }
}
