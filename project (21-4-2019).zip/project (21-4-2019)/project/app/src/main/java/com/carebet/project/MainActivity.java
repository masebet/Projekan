package com.carebet.project;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    double suhu = 0.0;
    int detak = 0;
    int otot= 0;
    String command="mulai";
    String transisi="mulai";
    private String TAG = MainActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private TextView lv;
    private TextView lv2;
    private TextView lv3;
    private TextView hasil,kesimpulan;
    private Button Thasil,Treset;
    private static String url = "http://192.168.4.1/";
    int avOtot,avDetak,avSum; double avSuhu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setup();
        loop();
    }

    public void setup(){
        lv = (TextView) findViewById(R.id.detak);                   //pojok kiri bawah data real
        lv2 = (TextView) findViewById(R.id.suhu);                   //-----||------
        lv3 = (TextView) findViewById(R.id.otot);                   //-----||------
        hasil = (TextView) findViewById(R.id.Hhitung);              //kotak tengah
        kesimpulan = (TextView) findViewById(R.id.kesimpulan);
        Thasil = (Button)findViewById(R.id.Thitung);                //tombol hasil
        Treset = (Button)findViewById(R.id.Treset);                 //tombol reset

        lv3.setText("Nilai Sensor Otot" );
        lv2.setText("Nilai Sensor Detak");
        lv.setText("Nilai Sensor Suhu");

        Thasil.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(command=="mulai")command="hitungJalan";else
                if(command=="hitungJalan")command="mulai";
            }
        });

        Treset.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(command=="mulai")command="reset";else
                if(command=="reset")command="mulai";
            }
        });
    }

    String interfaceData="";
    public void loop(){
        //========================
        new GetData().execute();
        //=========================awal tombol
        if(command=="mulai") {
            interfaceData = "Data Suhu\t\t" + avSuhu + " Celsius\n";
            if(avSuhu<60&&avSuhu>25){interfaceData +="Normal\n"; }else{interfaceData +="Tidak Normal\n";}
            interfaceData +="Data Detak\t\t" + avDetak + " BPM\n";
            if(avDetak<150&&avDetak>40){interfaceData +="Normal\n"; }else{interfaceData +="Tidak Normal\n";}
            if(otot>400){interfaceData +="Otot Berkontraksi\n";}else{interfaceData +="Otot Relaksasi\n";}
            hasil.setText(interfaceData);
            Thasil.setText(command);
        }
        //=========================jika tombol jalan ditekan
        if(command=="hitungJalan"){
            hasil.setText("Proses "+avSum);
            avSum++;
            avDetak+=detak;
            avSuhu+=suhu;
            avOtot+=otot;
            if(avSum>=100){
                command="mulai";
                avSuhu = avSuhu / avSum;
                avDetak = avDetak / avSum;
                avOtot = avOtot / avSum;
            }
            if(avSum>100){command="reset";transisi="reset";}
             Thasil.setText("Stop");
        }
        //=========================jika tombol reset ditekan
        if(command=="reset") {
            command="mulai";
            avDetak=0; avSuhu=0; avOtot=0; avSum=0;
        }
        reload(100);
    }
//====================================ini cuman fungsi tambahan===================
    private void reload(long delay){
        final Handler handler=new Handler();
        final Runnable runnable=new Runnable() {
            @Override
            public void run() {
                loop();
            }
        };
        handler.postDelayed(runnable,delay);
    }
    private class GetData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);
            if(jsonStr==null) return null;
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    detak = jsonObj.getInt("detak");
                    suhu = jsonObj.getDouble("suhu");
                    otot = jsonObj.getInt("otot");
                } catch (final JSONException e) {
                    Log.e(TAG, "eror" + e.getMessage());
                    runOnUiThread(new Runnable() {@Override public void run() { Toast.makeText(getApplicationContext(), "eror kenapa?" + e.getMessage(), Toast.LENGTH_LONG).show(); }});
                }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            lv3.setText("Nilai Sensor Otot : "+otot);
            lv2.setText("Nilai Sensor Detak : "+detak+" BPM");
            lv.setText("Nilai Sensor Suhu : "+suhu+" Celcius");
        }
    }
}
